@extends('layouts.master')
@section('content')
 
<h1>Home</h1>
@stop